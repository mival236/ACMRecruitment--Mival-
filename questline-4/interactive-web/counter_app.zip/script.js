// Simple counter logic — instantly updates UI
(function(){
  const countEl = document.getElementById('count');
  const inc = document.getElementById('increment');
  const dec = document.getElementById('decrement');
  const reset = document.getElementById('reset');
  const stepInput = document.getElementById('step');

  let count = 0;

  function render(){
    countEl.textContent = count;
  }

  function getStep(){
    const val = parseInt(stepInput.value, 10);
    return Number.isFinite(val) && val > 0 ? val : 1;
  }

  inc.addEventListener('click', ()=>{
    count += getStep();
    render();
  });

  dec.addEventListener('click', ()=>{
    count -= getStep();
    render();
  });

  reset.addEventListener('click', ()=>{
    count = 0;
    render();
  });

  // keyboard support: ArrowUp -> increment, ArrowDown -> decrement, r -> reset
  window.addEventListener('keydown', (e)=>{
    if (e.key === 'ArrowUp') { count += getStep(); render(); }
    else if (e.key === 'ArrowDown') { count -= getStep(); render(); }
    else if (e.key.toLowerCase() === 'r') { count = 0; render(); }
  });

  // initial render
  render();
})();